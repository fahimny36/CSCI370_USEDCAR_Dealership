/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package project.usedcardealership;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Fahim
 */
public class PaypalTest {
    
    public PaypalTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of pay method, of class Paypal.
     */
    @Test
    public void testPay() {
             System.out.println("pay");
        Paypal instance = new Paypal();
        instance.UserName = "user1@abc.com";
        instance.Password = "Pass";
        instance.Amount = 2000;
        instance.pay();
    }
    
}
