/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.usedcardealership;


public class CreditCard extends PaymentMethod{
    public int CVV;
    public String CardNumber;
    
        public void pay()
    {
        if(CardNumber.length() == 16){
            if(CVV <99 &&CVV>999){
        System.out.println(Amount+" Paid by Credit Card Number: "+CardNumber);
            }
            else{
                System.out.println("Invalid CVV "+ CVV);
            }
        }
        else{
                    System.out.println("Invalid Card Number "+CardNumber);

        }
    }
}
