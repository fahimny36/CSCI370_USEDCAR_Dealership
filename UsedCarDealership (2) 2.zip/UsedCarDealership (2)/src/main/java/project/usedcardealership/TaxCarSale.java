/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.usedcardealership;

public class TaxCarSale extends UsedCarSale{
 
   public double TaxPercent;
   public double TaxPrice;
   @Override
   public void PriceCalculation() {
      if(TaxPercent == 0)
      {
          System.out.println("Tax cannot be zero percent. Go For Tax Free Sales");
          return;
      }
      TaxPrice = CarPrice*TaxPercent/100;
      CarPrice = TaxPrice+CarPrice;

        System.out.println("Price To Be Paid With Tax: "+ CarPrice);
    
   }
}