/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template

 */
package project.usedcardealership;

public abstract class UsedCarSale {
    public double CarPrice = 0;
    public String Color = "Red";
    public int YearOfManufacturing = 2020;
    public String Model ="AB231";
    public String StateOfSale ="Ohio";
    public PaymentMethod PaymentType;
   /* public UsedCarSale(int cp,String clr, int yr, String mod, String state, PaymentMethod pm)
    {
        CarPrice = cp;
        Color = clr;
        YearOfManufacturing = yr;
        Model= mod;
        StateOfSale = state;
        PaymentType = pm;
    }*/
    public abstract void PriceCalculation();
}
