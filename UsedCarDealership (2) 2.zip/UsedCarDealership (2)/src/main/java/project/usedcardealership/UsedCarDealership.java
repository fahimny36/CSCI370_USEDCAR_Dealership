/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package project.usedcardealership;

public class UsedCarDealership {

    public static void main(String[] args) {
        //System.out.println("Hello World!");
// Unit Tests

        // Component Test
        RunComponentTest();
        
        //Negative Test Cases;
        RunNegativeTest();
    }
        public static void RunNegativeTest()
    {
        System.out.println("\nNegative Test\n------------------------");
        // Paypal Object Creation
        Paypal paypal = new Paypal();
        paypal.Amount= 1500;
        paypal.UserName = "UserX";
        paypal.Password = "Passsword1223";
        
        //CreditCard Object Creation
        CreditCard cc = new CreditCard();
        cc.Amount = 3000;
        cc.CVV = 233;
        cc.CardNumber="123465609386565";

        CreditCard cc2 = new CreditCard();
        cc2.Amount = 3000;
        cc2.CVV = 23;
        cc2.CardNumber="1234656909386565";
        cc2.pay();
        
        TaxCarSale car1 = new TaxCarSale();
        car1.CarPrice= 1500;
        car1.PaymentType = paypal;
        car1.TaxPercent= 0;
        car1.PriceCalculation();
        car1.PaymentType.pay();
        
        TaxFreeCarSale car2 = new TaxFreeCarSale();
        car2.CarPrice=3000;
        car2.PaymentType= cc;
        car2.PriceCalculation();
        car2.PaymentType.pay();
    }
    public static void RunComponentTest()
    {
         System.out.println("\nComponent Test\n------------------------");
        // Paypal Object Creation
        Paypal paypal = new Paypal();
        paypal.Amount= 1500;
        paypal.UserName = "userX@abc.com";
        paypal.Password = "Passsword1223";
        
        //CreditCard Object Creation
        CreditCard cc = new CreditCard();
        cc.Amount = 3000;
        cc.CVV = 233;
        cc.CardNumber="1234656909386565";

        TaxCarSale car1 = new TaxCarSale();
        car1.CarPrice= 1500;
        car1.PaymentType = paypal;
        car1.TaxPercent= 5;
        car1.PriceCalculation();
        car1.PaymentType.pay();
        
        TaxFreeCarSale car2 = new TaxFreeCarSale();
        car2.CarPrice=3000;
        car2.PaymentType= cc;
        
        car2.PriceCalculation();
        car2.PaymentType.pay();
        
   
    }
}



// Online Java Compiler
// Use this editor to write, compile and run your Java code online





