/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.usedcardealership;


public class Paypal extends PaymentMethod {
    public String UserName;
    public String Password;
    
    public void pay()
    {
        if(UserName.matches("^(.+)@(.+)$"))
        System.out.println(Amount+" Paid by PayPal User: "+UserName);
        
        else{
                    System.out.println("Username must be a valid email. Invalid Username: "+UserName);

        }
    }
}
