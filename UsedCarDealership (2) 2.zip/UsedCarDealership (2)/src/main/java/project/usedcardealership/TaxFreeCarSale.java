/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.usedcardealership;


public class TaxFreeCarSale extends UsedCarSale{

   @Override
   public void PriceCalculation() {
      System.out.println("Price To Be Paid for Tax Free Car Sale: "+ CarPrice);
   }
}